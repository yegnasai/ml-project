import { gateway, generateText } from 'ai'
import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const question = typeof body.question === 'string' ? body.question.trim() : ''
    const history = Array.isArray(body.history) ? body.history.slice(-6) : []
    const prediction = body.prediction ?? {}

    if (!question) return NextResponse.json({ error: 'Ask a question to get started.' }, { status: 400 })

    const context = history
      .map((message: { role?: string; content?: string }) => `${message.role === 'user' ? 'Business owner' : 'Coach'}: ${String(message.content ?? '').slice(0, 800)}`)
      .join('\n')

    const result = await generateText({
      model: gateway('openai/o4-mini'),
      system: `You are PredictIQ Business Coach. Give practical, concise advice for a small business using customer purchase prediction. Explain what the prediction means, suggest ethical growth experiments, and include a measurable next step. Never claim certainty, never invent data, and remind the owner that the model supports rather than replaces judgment. Current model context: Logistic Regression ${prediction.logistic ?? 'unknown'}%, Random Forest ${prediction.forest ?? 'unknown'}%, threshold ${prediction.threshold ?? 50}%.\nConversation:\n${context}`,
      prompt: question,
    })

    return NextResponse.json({ answer: result.text })
  } catch (error) {
    console.error('[v0] Business coach error:', error)
    return NextResponse.json({ error: 'The business coach is temporarily unavailable.' }, { status: 500 })
  }
}
