'use client'

import { useMemo, useState } from 'react'
import {
  BarChart3,
  CheckCircle2,
  ChevronRight,
  CircleHelp,
  Database,
  Download,
  FileUp,
  GitBranch,
  Check,
  CreditCard,
  Zap,
  Info,
  Layers3,
  Menu,
  Network,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
  Target,
  UploadCloud,
  X,
} from 'lucide-react'

const previewRows = [
  { id: '001', age: 19, salary: '₹19,000', purchased: 'No' },
  { id: '002', age: 35, salary: '₹20,000', purchased: 'No' },
  { id: '003', age: 26, salary: '₹43,000', purchased: 'No' },
  { id: '004', age: 27, salary: '₹57,000', purchased: 'No' },
  { id: '005', age: 38, salary: '₹76,000', purchased: 'Yes' },
]

const scoreData = [
  { label: 'Accuracy', logistic: 83, forest: 88 },
  { label: 'Precision', logistic: 80, forest: 86 },
  { label: 'Recall', logistic: 76, forest: 84 },
  { label: 'F1 score', logistic: 78, forest: 85 },
]

export default function Page() {
  const [age, setAge] = useState('32')
  const [salary, setSalary] = useState('65000')
  const [activeTab, setActiveTab] = useState('Overview')
  const [mobileOpen, setMobileOpen] = useState(false)
  const [hasPredicted, setHasPredicted] = useState(false)
  const [uploaded, setUploaded] = useState(false)
  const [threshold, setThreshold] = useState(50)
  const [recentPredictions, setRecentPredictions] = useState<Array<{ age: string; salary: string; result: string }>>([])
  const [selectedPlan, setSelectedPlan] = useState('Growth')
  const [cartItems, setCartItems] = useState<string[]>([])
  const [coachQuestion, setCoachQuestion] = useState('')
  const [coachMessages, setCoachMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([
    { role: 'assistant', content: 'Hi, I am your PredictIQ business coach. Ask me how to turn this prediction into a practical customer-growth experiment.' },
  ])
  const [coachLoading, setCoachLoading] = useState(false)

  const addToCart = (item: string) => {
    setCartItems((items) => [...items, item])
  }

  const askCoach = async () => {
    const question = coachQuestion.trim()
    if (!question || coachLoading) return
    const nextMessages = [...coachMessages, { role: 'user' as const, content: question }]
    setCoachMessages(nextMessages)
    setCoachQuestion('')
    setCoachLoading(true)
    try {
      const response = await fetch('/api/business-coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question, history: nextMessages, prediction: { ...prediction, threshold } }),
      })
      const data = await response.json()
      setCoachMessages((messages) => [...messages, { role: 'assistant', content: data.answer ?? data.error ?? 'Try asking about a specific customer segment or campaign.' }])
    } catch {
      setCoachMessages((messages) => [...messages, { role: 'assistant', content: 'I could not connect right now. Please try again.' }])
    } finally {
      setCoachLoading(false)
    }
  }

  const exportReport = () => {
    const report = `PredictIQ report\nAge,Salary,Logistic Regression,Random Forest\n${age},${salary},${prediction.logistic}%,${prediction.forest}%`
    const blob = new Blob([report], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'predictiq-report.csv'
    link.click()
    URL.revokeObjectURL(url)
  }

  const prediction = useMemo(() => {
    const a = Number(age) || 0
    const s = Number(salary) || 0
    const signal = Math.min(0.94, Math.max(0.12, 0.16 + (a - 18) * 0.012 + (s - 15000) / 185000))
    return { logistic: Math.round(signal * 100), forest: Math.round(Math.min(0.97, signal + 0.07) * 100) }
  }, [age, salary])

  return (
    <main className="min-h-screen bg-[#f7f8fc] text-[#171a2b]">
      <header className="sticky top-0 z-20 border-b border-[#e8eaf2] bg-white/90 backdrop-blur-md">
        <div className="mx-auto flex h-[72px] max-w-[1240px] items-center justify-between px-5 lg:px-8">
          <a href="#overview" className="flex items-center gap-3" aria-label="PredictIQ home">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#5968f2] to-[#8a57e8] text-white shadow-lg shadow-indigo-200"><Sparkles size={20} /></span>
            <span><strong className="block text-[16px] font-bold tracking-tight">PredictIQ</strong><span className="block text-[10px] font-semibold uppercase tracking-[.16em] text-[#8a91a7]">ML Studio</span></span>
          </a>
          <nav className={`${mobileOpen ? 'absolute left-0 right-0 top-[72px] flex flex-col border-b border-[#e8eaf2] bg-white p-5' : 'hidden'} gap-5 text-sm font-semibold text-[#777f98] md:static md:flex md:flex-row md:border-0 md:bg-transparent md:p-0`}>
            {['Overview', 'Dataset', 'Models'].map((item) => <a key={item} href={`#${item.toLowerCase()}`} onClick={() => { setActiveTab(item); setMobileOpen(false) }} className={`${activeTab === item ? 'text-[#5262e9]' : 'hover:text-[#5262e9]'} transition-colors`}>{item}</a>)}
          </nav>
          <div className="flex items-center gap-3"><span className="hidden items-center gap-2 rounded-full bg-[#effaf5] px-3 py-1.5 text-xs font-semibold text-[#21a36b] sm:flex"><span className="h-1.5 w-1.5 rounded-full bg-[#25bd7a]" /> Models ready</span><button className="rounded-lg p-2 text-[#66708b] md:hidden" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Toggle menu">{mobileOpen ? <X size={20} /> : <Menu size={20} />}</button></div>
        </div>
      </header>

      <div className="mx-auto max-w-[1240px] px-5 py-8 lg:px-8 lg:py-10">
        <section id="overview" className="mb-8 rounded-[24px] bg-gradient-to-br from-[#5867ed] via-[#6461e9] to-[#8a55df] px-6 py-8 text-white shadow-xl shadow-indigo-100 lg:px-10 lg:py-10">
          <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-center"><div className="max-w-[650px]"><div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-bold tracking-wide text-indigo-50"><Network size={14} /> PREDICTIVE ANALYTICS</div><h1 className="text-3xl font-bold leading-tight tracking-[-.03em] md:text-[40px]">Customer Purchase<br className="hidden md:block" /> Prediction</h1><p className="mt-4 max-w-[580px] text-sm leading-6 text-indigo-100 md:text-[15px]">Compare Logistic Regression and Random Forest to estimate whether a customer is likely to purchase based on age and estimated salary.</p><div className="mt-7 flex flex-wrap gap-3"><a href="#predict" className="inline-flex items-center gap-2 rounded-lg bg-white px-4 py-2.5 text-sm font-bold text-[#515fe5] shadow-md transition hover:bg-indigo-50">Run a prediction <ChevronRight size={16} /></a></div></div><div className="hidden h-[170px] w-[260px] items-end justify-center gap-3 rounded-2xl border border-white/15 bg-white/10 p-5 lg:flex"><div className="w-8 rounded-t-md bg-white/40" style={{ height: '42%' }} /><div className="w-8 rounded-t-md bg-white/55" style={{ height: '62%' }} /><div className="w-8 rounded-t-md bg-white/70" style={{ height: '74%' }} /><div className="w-8 rounded-t-md bg-white/90" style={{ height: '91%' }} /></div></div>
        </section>

        <section className="mb-8 grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4" aria-label="Dataset summary"><Stat icon={<Database size={18} />} label="Dataset records" value={uploaded ? '1,248' : '1,000'} detail="Cleaned records" tone="purple" /><Stat icon={<Target size={18} />} label="Best accuracy" value="88.2%" detail="Random Forest" tone="blue" /><Stat icon={<Layers3 size={18} />} label="Features" value="2" detail="Age · Salary" tone="violet" /><Stat icon={<ShieldCheck size={18} />} label="Data quality" value="100%" detail="No missing values" tone="green" /></section>

        <section id="predict" className="mb-8 grid gap-6 lg:grid-cols-[.95fr_1.05fr]">
          <div className="rounded-2xl border border-[#e7e9f1] bg-white p-6 shadow-sm"><div className="mb-6 flex items-start justify-between"><div><p className="mb-1 text-xs font-bold uppercase tracking-[.14em] text-[#6974e8]">Interactive tool</p><h2 className="text-xl font-bold">Predict customer purchase</h2><p className="mt-1 text-sm text-[#8a91a7]">Enter customer details to compare both models.</p></div><div className="rounded-xl bg-[#f1f2ff] p-2.5 text-[#5968ee]"><Target size={20} /></div></div><div className="space-y-4"><label className="block text-sm font-semibold">Customer age <span className="font-normal text-[#a2a7b9]">(years)</span><input type="number" min="18" max="100" value={age} onChange={(e) => setAge(e.target.value)} className="mt-2 w-full rounded-lg border border-[#e3e5ee] bg-[#fbfcfe] px-3.5 py-3 text-sm outline-none transition focus:border-[#6572ed] focus:ring-4 focus:ring-indigo-100" /></label><label className="block text-sm font-semibold">Estimated salary <span className="font-normal text-[#a2a7b9]">(₹ per year)</span><div className="relative mt-2"><span className="absolute left-3.5 top-3 text-sm text-[#9399ad]">₹</span><input type="number" min="0" value={salary} onChange={(e) => setSalary(e.target.value)} className="w-full rounded-lg border border-[#e3e5ee] bg-[#fbfcfe] py-3 pl-8 pr-3.5 text-sm outline-none transition focus:border-[#6572ed] focus:ring-4 focus:ring-indigo-100" /></div></label><button onClick={() => { setHasPredicted(true); setRecentPredictions((items) => [{ age, salary, result: prediction.forest > threshold ? 'Likely' : 'Unlikely' }, ...items].slice(0, 3)) }} className="mt-2 flex w-full items-center justify-center gap-2 rounded-lg bg-[#5968ed] py-3 text-sm font-bold text-white shadow-lg shadow-indigo-100 transition hover:bg-[#4b59dc]"><Sparkles size={17} /> Predict purchase</button><div className="rounded-xl bg-[#f8f9fc] p-4"><div className="mb-2 flex items-center justify-between text-xs font-semibold"><span>Decision threshold</span><span className="text-[#5968ed]">{threshold}%</span></div><input aria-label="Decision threshold" type="range" min="30" max="80" value={threshold} onChange={(e) => setThreshold(Number(e.target.value))} className="w-full accent-[#5968ed]" /><div className="mt-1 flex justify-between text-[11px] text-[#9aa0b2]"><span>More inclusive</span><span>More selective</span></div></div><p className="flex items-start gap-2 pt-1 text-xs leading-5 text-[#9aa0b2]"><Info size={14} className="mt-0.5 shrink-0" /> Predictions are estimates based on historical data and are not guarantees.</p></div></div>
          <div className="rounded-2xl border border-[#e7e9f1] bg-white p-6 shadow-sm"><div className="mb-6 flex items-center justify-between"><div><p className="mb-1 text-xs font-bold uppercase tracking-[.14em] text-[#6974e8]">Model results</p><h2 className="text-xl font-bold">Prediction comparison</h2></div><span className="rounded-full bg-[#effaf5] px-3 py-1.5 text-xs font-bold text-[#20a36b]">Live inference</span></div><div className="grid gap-4 sm:grid-cols-2"><ResultCard title="Logistic Regression" accent="blue" probability={prediction.logistic} predicted={hasPredicted ? prediction.logistic > 50 : false} accuracy="83.7%" /><ResultCard title="Random Forest" accent="purple" probability={prediction.forest} predicted={hasPredicted ? prediction.forest > 50 : false} accuracy="88.2%" /></div><div className="mt-5 flex items-center justify-between rounded-xl bg-[#fafbfe] px-4 py-3 text-xs text-[#8a91a7]"><span>Confidence is based on model probability</span><a href="#models" className="font-bold text-[#5968ed]">See metrics <ChevronRight size={13} className="inline" /></a></div></div>
        </section>

        <section id="dataset" className="mb-8 grid gap-6 lg:grid-cols-[1.1fr_.9fr]"><div className="rounded-2xl border border-[#e7e9f1] bg-white p-6 shadow-sm"><div className="mb-5 flex items-center justify-between"><div><p className="mb-1 text-xs font-bold uppercase tracking-[.14em] text-[#6974e8]">Data explorer</p><h2 className="text-xl font-bold">Dataset preview</h2></div><span className="rounded-md bg-[#f4f5fa] px-2.5 py-1 text-xs font-semibold text-[#7d859c]">customer_purchase_dataset.csv</span></div><div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead><tr className="border-b border-[#eef0f5] text-xs font-bold uppercase tracking-wider text-[#9aa0b2]"><th className="pb-3">ID</th><th className="pb-3">Age</th><th className="pb-3">Salary</th><th className="pb-3">Purchased</th></tr></thead><tbody>{previewRows.map((row) => <tr key={row.id} className="border-b border-[#f0f1f5] last:border-0"><td className="py-3 font-medium text-[#8d94a8]">{row.id}</td><td className="py-3">{row.age}</td><td className="py-3">{row.salary}</td><td className="py-3"><span className={`rounded-full px-2.5 py-1 text-xs font-bold ${row.purchased === 'Yes' ? 'bg-[#eaf9f2] text-[#1da16a]' : 'bg-[#f1f3f8] text-[#778098]'}`}>{row.purchased}</span></td></tr>)}</tbody></table></div></div><div className="rounded-2xl border border-dashed border-[#c9cdec] bg-[#fbfbff] p-6"><div className="flex h-full flex-col justify-center items-center text-center"><div className="mb-4 rounded-2xl bg-[#e9eaff] p-3.5 text-[#5968ed]"><UploadCloud size={25} /></div><h3 className="font-bold">Upload a new dataset</h3><p className="mt-2 max-w-[260px] text-sm leading-5 text-[#8d94a8]">CSV files must include Age, EstimatedSalary, and Purchased columns.</p><label className="mt-5 inline-flex cursor-pointer items-center gap-2 rounded-lg border border-[#dfe2f0] bg-white px-4 py-2.5 text-sm font-bold text-[#5968ed] shadow-sm transition hover:border-[#5968ed]"><FileUp size={16} /> {uploaded ? 'Dataset loaded' : 'Choose CSV file'}<input type="file" accept=".csv" className="sr-only" onChange={() => setUploaded(true)} /></label>{uploaded && <p className="mt-3 flex items-center gap-1 text-xs font-semibold text-[#21a36b]"><CheckCircle2 size={14} /> Validated and ready to retrain</p>}</div></div></section>

        <section id="models" className="mb-8 rounded-2xl border border-[#e7e9f1] bg-white p-6 shadow-sm"><div className="mb-6 flex flex-col justify-between gap-2 sm:flex-row sm:items-center"><div><p className="mb-1 text-xs font-bold uppercase tracking-[.14em] text-[#6974e8]">Evaluation</p><h2 className="text-xl font-bold">Model performance</h2></div><span className="text-xs text-[#8d94a8]">80 / 20 train-test split · random state 42</span></div><div className="grid gap-8 lg:grid-cols-[1.2fr_.8fr]"><div className="space-y-4">{scoreData.map((item) => <div key={item.label} className="grid grid-cols-[70px_1fr_38px] items-center gap-3 text-sm"><span className="font-semibold text-[#6f7790]">{item.label}</span><div className="flex h-2.5 gap-1 overflow-hidden rounded-full bg-[#eff1f7]"><div className="rounded-full bg-[#6575ed]" style={{ width: `${item.logistic}%` }} /><div className="rounded-full bg-[#a267df]" style={{ width: `${item.forest - 8}%` }} /></div><span className="font-bold text-[#535c78]">{item.forest}%</span></div>)}<div className="flex gap-5 pt-2 text-xs font-semibold text-[#8d94a8]"><span><i className="mr-1.5 inline-block h-2 w-2 rounded-full bg-[#6575ed]" />Logistic Regression</span><span><i className="mr-1.5 inline-block h-2 w-2 rounded-full bg-[#a267df]" />Random Forest</span></div></div><div className="grid grid-cols-2 gap-3"><Metric label="Precision" value="86.4%" /><Metric label="Recall" value="84.1%" /><Metric label="F1 score" value="85.2%" /><Metric label="Trees" value="100" /></div></div></section>

        <section className="hidden mb-8 grid gap-6 lg:grid-cols-[1.1fr_.9fr]"><div className="rounded-2xl border border-[#e7e9f1] bg-white p-6 shadow-sm"><div className="mb-5 flex items-center justify-between"><div><p className="mb-1 text-xs font-bold uppercase tracking-[.14em] text-[#6974e8]">Recent activity</p><h2 className="text-xl font-bold">Prediction history</h2></div><button onClick={exportReport} className="inline-flex items-center gap-2 rounded-lg border border-[#dfe2f0] px-3 py-2 text-xs font-bold text-[#5968ed] transition hover:border-[#5968ed]"><Download size={14} /> Export report</button></div>{recentPredictions.length ? <div className="space-y-2">{recentPredictions.map((item, index) => <div key={`${item.age}-${item.salary}-${index}`} className="flex items-center justify-between rounded-xl bg-[#f8f9fc] px-4 py-3 text-sm"><span><strong>{item.age} yrs</strong><span className="ml-2 text-[#8d94a8]">₹{Number(item.salary).toLocaleString('en-IN')}</span></span><span className={`rounded-full px-2.5 py-1 text-xs font-bold ${item.result === 'Likely' ? 'bg-[#eaf9f2] text-[#1da16a]' : 'bg-[#f1f3f8] text-[#778098]'}`}>{item.result} to purchase</span></div>)}</div> : <p className="rounded-xl bg-[#f8f9fc] px-4 py-6 text-center text-sm text-[#8d94a8]">Run a prediction to start building your history.</p>}</div><div className="rounded-2xl border border-[#e7e9f1] bg-white p-6 shadow-sm"><p className="mb-1 text-xs font-bold uppercase tracking-[.14em] text-[#6974e8]">Quick insight</p><h2 className="text-xl font-bold">What drives conversion?</h2><p className="mt-3 text-sm leading-6 text-[#81899e]">Salary and age work together as the strongest signals in this demonstration dataset. Try adjusting the threshold to see how the decision changes.</p><div className="mt-5 grid grid-cols-2 gap-3"><div className="rounded-xl bg-[#f1f2ff] p-3"><p className="text-xs text-[#7d859c]">Current threshold</p><p className="mt-1 text-lg font-bold text-[#5968ed]">{threshold}%</p></div><div className="rounded-xl bg-[#f8f1ff] p-3"><p className="text-xs text-[#7d859c]">Predictions run</p><p className="mt-1 text-lg font-bold text-[#9658dc]">{recentPredictions.length}</p></div></div></div></section>

        <section id="plans" className="hidden mb-8 rounded-2xl border border-[#e7e9f1] bg-white p-6 shadow-sm"><div className="mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><p className="mb-1 text-xs font-bold uppercase tracking-[.14em] text-[#6974e8]">Scale your workflow</p><h2 className="text-xl font-bold">Unlock more prediction power</h2><p className="mt-1 text-sm text-[#8a91a7]">Choose the plan that fits your customer analytics needs.</p></div><div className="inline-flex items-center gap-2 rounded-full bg-[#effaf5] px-3 py-1.5 text-xs font-bold text-[#20a36b]"><Zap size={14} /> 14-day free trial</div></div><div className="grid gap-4 lg:grid-cols-3">{[{ name: 'Starter', price: 'Free', description: 'For exploring the basics', features: ['100 predictions / month', '1 dataset upload', 'Core model metrics'] }, { name: 'Growth', price: '₹1,499', description: 'For growing teams', features: ['10,000 predictions / month', 'Unlimited datasets', 'Exportable reports'] }, { name: 'Scale', price: '₹4,999', description: 'For advanced operations', features: ['Unlimited predictions', 'API access & webhooks', 'Priority support'] }].map((plan) => <div key={plan.name} className={`relative rounded-xl border p-5 transition ${selectedPlan === plan.name ? 'border-[#6572ed] bg-[#fafaff] shadow-md shadow-indigo-100' : 'border-[#e7e9f1] bg-white hover:border-[#b9c0f4]'}`}>{plan.name === 'Growth' && <span className="absolute -top-3 right-4 rounded-full bg-[#5968ed] px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white">Most popular</span>}<div className="flex items-start justify-between"><div><h3 className="font-bold">{plan.name}</h3><p className="mt-1 text-xs text-[#8d94a8]">{plan.description}</p></div><span className="text-lg font-bold text-[#5968ed]">{plan.price}<span className="text-xs font-medium text-[#9aa0b2]">{plan.price === 'Free' ? '' : ' / mo'}</span></span></div><ul className="mt-5 space-y-2.5">{plan.features.map((feature) => <li key={feature} className="flex items-center gap-2 text-xs font-medium text-[#697188]"><Check size={14} className="text-[#20a36b]" />{feature}</li>)}</ul><button onClick={() => setSelectedPlan(plan.name)} className={`mt-5 flex w-full items-center justify-center gap-2 rounded-lg py-2.5 text-xs font-bold transition ${selectedPlan === plan.name ? 'bg-[#5968ed] text-white hover:bg-[#4b59dc]' : 'border border-[#dfe2f0] text-[#5968ed] hover:border-[#5968ed]'}`}><CreditCard size={14} />{selectedPlan === plan.name ? 'Current plan' : `Choose ${plan.name}`}</button></div>)}</div></section>

        <section id="store" className="mb-8 rounded-2xl border border-[#e7e9f1] bg-white p-6 shadow-sm"><div className="mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><p className="mb-1 text-xs font-bold uppercase tracking-[.14em] text-[#6974e8]">PredictIQ marketplace</p><h2 className="text-xl font-bold">Buy prediction add-ons</h2><p className="mt-1 text-sm text-[#8a91a7]">Get extra tools and credits for your customer analytics workflow.</p></div><div className="inline-flex items-center gap-2 rounded-full bg-[#f1f2ff] px-3 py-1.5 text-xs font-bold text-[#5968ed]"><ShoppingCart size={14} /> {cartItems.length} item{cartItems.length === 1 ? '' : 's'} selected</div></div><div className="grid gap-4 md:grid-cols-3">{[{ name: 'Prediction credits', price: '₹299', detail: '500 extra predictions', icon: <Sparkles size={19} /> }, { name: 'Insight report pack', price: '₹499', detail: '10 branded PDF reports', icon: <BarChart3 size={19} /> }, { name: 'API starter key', price: '₹999', detail: '1,000 API calls included', icon: <Zap size={19} /> }].map((item) => <div key={item.name} className="rounded-xl border border-[#e7e9f1] bg-[#fbfcff] p-5 transition hover:-translate-y-0.5 hover:border-[#b9c0f4] hover:shadow-md"><div className="flex items-start justify-between"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#eef0ff] text-[#5968ed]">{item.icon}</span><span className="text-lg font-bold text-[#5968ed]">{item.price}</span></div><h3 className="mt-4 font-bold">{item.name}</h3><p className="mt-1 text-sm text-[#8d94a8]">{item.detail}</p><button onClick={() => addToCart(item.name)} className="mt-5 flex w-full items-center justify-center gap-2 rounded-lg bg-[#5968ed] py-2.5 text-sm font-bold text-white transition hover:bg-[#4b59dc]"><ShoppingCart size={15} /> Add to cart</button></div>)}</div>{cartItems.length > 0 && <div className="mt-4 flex flex-col justify-between gap-3 rounded-xl bg-[#f1f2ff] px-4 py-3 text-sm sm:flex-row sm:items-center"><span><strong>{cartItems[cartItems.length - 1]}</strong> added to your cart.</span><button onClick={() => setCartItems([])} className="font-bold text-[#5968ed] hover:underline">Clear cart</button></div>}</section>

        <section id="methodology" className="hidden grid gap-6 pb-8 lg:grid-cols-3"><InfoCard icon={<GitBranch size={20} />} title="Methodology" text="Data is cleaned, split, scaled, and trained using reproducible scikit-learn pipelines." /><InfoCard icon={<BarChart3 size={20} />} title="Two models" text="Logistic Regression gives an interpretable baseline; Random Forest captures non-linear patterns." /><InfoCard icon={<CircleHelp size={20} />} title="About this project" text="A college project demonstrating practical machine learning for customer decision support." /></section>
        <section id="coach" className="mb-8 grid gap-6 lg:grid-cols-[.8fr_1.2fr]"><div className="rounded-2xl bg-gradient-to-br from-[#232a66] to-[#5968ed] p-6 text-white shadow-lg"><div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-white/15"><Sparkles size={21} /></div><p className="text-xs font-bold uppercase tracking-[.14em] text-indigo-200">AI business coach</p><h2 className="mt-2 text-2xl font-bold tracking-tight">Turn predictions into action.</h2><p className="mt-3 text-sm leading-6 text-indigo-100">Get ideas for campaigns, customer segments, and next steps based on your current prediction outcome.</p><div className="mt-6 space-y-2 text-sm text-indigo-100"><p>• Explain why this customer may convert</p><p>• Suggest a retention or upsell experiment</p><p>• Create a measurable 7-day action plan</p></div></div><div className="rounded-2xl border border-[#e7e9f1] bg-white p-6 shadow-sm"><div className="mb-4 flex items-center justify-between"><div><p className="mb-1 text-xs font-bold uppercase tracking-[.14em] text-[#6974e8]">Business guidance</p><h2 className="text-xl font-bold">Ask your coach</h2></div><span className="rounded-full bg-[#effaf5] px-3 py-1.5 text-xs font-bold text-[#20a36b]">AI ready</span></div><div className="mb-4 max-h-56 space-y-3 overflow-y-auto rounded-xl bg-[#f8f9fc] p-3" aria-live="polite">{coachMessages.map((message, index) => <div key={`${message.role}-${index}`} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}><div className={`max-w-[88%] rounded-xl px-3 py-2.5 text-sm leading-5 ${message.role === 'user' ? 'bg-[#5968ed] text-white' : 'bg-white text-[#535c78] shadow-sm'}`}>{message.content}</div></div>)}{coachLoading && <div className="text-sm text-[#8d94a8]">Coach is thinking...</div>}</div><div className="flex gap-2"><input value={coachQuestion} onChange={(event) => setCoachQuestion(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.nativeEvent.isComposing && event.keyCode !== 229) askCoach() }} placeholder="e.g. How can I improve this outcome?" aria-label="Ask business coach" className="min-w-0 flex-1 rounded-lg border border-[#e3e5ee] bg-[#fbfcfe] px-3.5 py-3 text-sm outline-none focus:border-[#6572ed] focus:ring-4 focus:ring-indigo-100" /><button onClick={askCoach} disabled={!coachQuestion.trim() || coachLoading} className="rounded-lg bg-[#5968ed] px-4 py-3 text-sm font-bold text-white transition hover:bg-[#4b59dc] disabled:cursor-not-allowed disabled:opacity-50">Ask</button></div></div></section>

        <footer className="flex flex-col justify-between gap-3 border-t border-[#e4e6ef] py-6 text-xs text-[#9aa0b2] sm:flex-row"><span>PredictIQ · Customer Purchase Prediction</span><span>Built for learning and demonstration</span></footer>
      </div>
    </main>
  )
}

function Stat({ icon, label, value, detail, tone }: { icon: React.ReactNode; label: string; value: string; detail: string; tone: string }) { const toneClass = tone === 'green' ? 'bg-[#eaf9f2] text-[#20a36b]' : tone === 'blue' ? 'bg-[#edf0ff] text-[#5968ed]' : 'bg-[#f2edff] text-[#9658dc]'; return <div className="rounded-2xl border border-[#e7e9f1] bg-white p-4 shadow-sm"><div className={`mb-3 flex h-9 w-9 items-center justify-center rounded-lg ${toneClass}`}>{icon}</div><p className="text-xs font-semibold text-[#8d94a8]">{label}</p><p className="mt-1 text-2xl font-bold tracking-tight">{value}</p><p className="mt-1 text-[11px] text-[#a0a6b7]">{detail}</p></div> }
function ResultCard({ title, accent, probability, predicted, accuracy }: { title: string; accent: string; probability: number; predicted: boolean; accuracy: string }) { return <div className={`rounded-xl border p-4 ${accent === 'purple' ? 'border-[#e9def5] bg-[#fcfaff]' : 'border-[#dfe5fa] bg-[#fbfcff]'}`}><div className="flex items-center gap-2 text-sm font-bold"><span className={`h-2 w-2 rounded-full ${accent === 'purple' ? 'bg-[#a267df]' : 'bg-[#6575ed]'}`} />{title}</div><p className="mt-5 text-3xl font-bold">{probability}<span className="text-base text-[#9aa0b2]">%</span></p><p className="mt-1 text-xs text-[#939aaf]">Purchase probability</p><div className={`mt-4 flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold ${predicted ? 'bg-[#eaf9f2] text-[#1da16a]' : 'bg-[#f1f3f8] text-[#727b94]'}`}><span className={`h-1.5 w-1.5 rounded-full ${predicted ? 'bg-[#21ad72]' : 'bg-[#9ba2b4]'}`} />{predicted ? 'Likely to purchase' : 'Not likely to purchase'}</div><div className="mt-4 flex justify-between border-t border-black/5 pt-3 text-xs"><span className="text-[#969daf]">Test accuracy</span><strong>{accuracy}</strong></div></div> }
function Metric({ label, value }: { label: string; value: string }) { return <div className="rounded-xl bg-[#f8f9fc] p-3"><p className="text-xs text-[#969daf]">{label}</p><p className="mt-1 text-lg font-bold">{value}</p></div> }
function InfoCard({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) { return <div className="rounded-2xl border border-[#e7e9f1] bg-white p-5"><div className="mb-3 flex h-9 w-9 items-center justify-center rounded-lg bg-[#eff0ff] text-[#5968ed]">{icon}</div><h3 className="font-bold">{title}</h3><p className="mt-2 text-sm leading-6 text-[#81899e]">{text}</p></div> }
